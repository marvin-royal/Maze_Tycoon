"""
Adapters that bridge Maze Tycoon's internal world to the pygame UI.

These helpers make it easy to take a sequence of maze / solver states and
view them using `run_maze_view` from `game.ui_pygame`.
"""

from __future__ import annotations

from typing import (
    Collection,
    Iterable,
    Iterator,
    Optional,
    Sequence,
    Tuple,
    List,
    Set
)

from .ui_pygame import MazeFrame, run_maze_view

Pos = Tuple[int, int]
GridLike = Sequence[Sequence[int]]  # or bool; we normalize below


def iter_frames_from_grids(
    grids: Sequence[Sequence[Sequence[int] | bool]],
    *,
    player_positions: Optional[Sequence[Optional[Pos]]] = None,
    entrance: Optional[Pos] = None,
    exit: Optional[Pos] = None,
    solution_paths: Optional[Sequence[Optional[Collection[Pos]]]] = None,
    visited_cells: Optional[Sequence[Optional[Collection[Pos]]]] = None,
    notes: Optional[Sequence[Optional[str]]] = None,
) -> Iterator[MazeFrame]:
    """
    Turn a sequence of 2D grids into a sequence of MazeFrame objects.

    Each element of `grids` should be a 2D structure (rows x cols) of ints
    or bools:

        0 / False -> floor
        1 / True  -> wall

    Optional per-step sequences may be provided:
        - player_positions[i]: (row, col) for that step
        - solution_paths[i]: collection of (row, col) cells on the "best" path
        - visited_cells[i]: collection of visited cells so far
        - notes[i]: short status string (e.g. solver state)

    If any of the optional sequences are shorter than `grids`, they are
    treated as None for remaining steps.
    """
    n_steps = len(grids)

    def safe_get(seq: Optional[Sequence], idx: int):
        if seq is None:
            return None
        if idx < len(seq):
            return seq[idx]
        return None

    for step_idx in range(n_steps):
        raw_grid = grids[step_idx]
        # Normalize to int grid
        int_grid: list[list[int]] = []
        for row in raw_grid:
            int_row: list[int] = []
            for cell in row:
                if isinstance(cell, bool):
                    int_row.append(1 if cell else 0)
                else:
                    int_row.append(int(cell))
            int_grid.append(int_row)

        frame = MazeFrame(
            grid=int_grid,
            player=safe_get(player_positions, step_idx),
            entrance=entrance,
            exit=exit,
            solution_path=safe_get(solution_paths, step_idx),
            visited=safe_get(visited_cells, step_idx),
            step_index=step_idx,
            note=safe_get(notes, step_idx),
        )
        yield frame


def view_grids_with_pygame(
    grids: Sequence[Sequence[Sequence[int] | bool]],
    *,
    player_positions: Optional[Sequence[Optional[Pos]]] = None,
    entrance: Optional[Pos] = None,
    exit: Optional[Pos] = None,
    solution_paths: Optional[Sequence[Optional[Collection[Pos]]]] = None,
    visited_cells: Optional[Sequence[Optional[Collection[Pos]]]] = None,
    notes: Optional[Sequence[Optional[str]]] = None,
    fps: int = 20,
    cell_size: int = 24,
    hud_height: int = 48,
    window_title: str = "Maze Tycoon Demo",
) -> None:
    """
    Convenience wrapper that builds MazeFrames from raw grids and launches the
    pygame viewer.

    This is ideal for quick demos and experiments where you already have
    a list of grids over time and just want to *see* them.
    """
    frames = iter_frames_from_grids(
        grids,
        player_positions=player_positions,
        entrance=entrance,
        exit=exit,
        solution_paths=solution_paths,
        visited_cells=visited_cells,
        notes=notes,
    )
    run_maze_view(
        frames,
        fps=fps,
        cell_size=cell_size,
        hud_height=hud_height,
        window_title=window_title,
    )

def iter_demo_walk_frames(
    rows: int = 10,
    cols: int = 10,
) -> Iterator[MazeFrame]:
    """Yield frames for an infinite L-shaped walk around the border."""
    # Prebuild static grid with border walls
    grid: List[List[int]] = [[0 for _ in range(cols)] for _ in range(rows)]
    for rr in range(rows):
        grid[rr][0] = 1
        grid[rr][cols - 1] = 1
    for cc in range(cols):
        grid[0][cc] = 1
        grid[rows - 1][cc] = 1

    # L-shaped path from top-left inside corner to bottom-right inside corner
    # We keep the path inside the border so we see the player move.
    path: List[Pos] = []
    for c in range(1, cols - 1):
        path.append((1, c))
    for r in range(2, rows - 1):
        path.append((r, cols - 2))

    entrance = path[0]
    exit_ = path[-1]
    solution_cells: Set[Pos] = set(path)

    global_step = 0
    lap = 0

    while True:
        lap += 1
        visited: Set[Pos] = set()
        for step_idx, pos in enumerate(path):
            visited.add(pos)

            frame = MazeFrame(
                grid=grid,
                player=pos,
                entrance=entrance,
                exit=exit_,
                solution_path=solution_cells,
                visited=set(visited),
                step_index=global_step,
                note=f"Lap {lap}, step {step_idx}",
            )
            yield frame
            global_step += 1


def demo_walk_loop() -> None:
    """Run the infinite demo walk until the window is closed."""
    frames = iter_demo_walk_frames(rows=10, cols=10)
    run_maze_view(
        frames,
        fps=15,
        cell_size=32,
        hud_height=48,
        window_title="Maze Tycoon Demo Walk (Looping)",
    )

def demo_walk() -> None:
    """Little L-shaped demo walk for pure enjoyment."""
    rows, cols = 10, 10

    grids: list[list[list[int]]] = []
    player_positions: list[Pos] = []
    notes: list[str] = []

    path: list[Pos] = []

    # Simple L-shaped path from (0, 0) to (9, 9)
    for c in range(cols):
        path.append((0, c))
    for r in range(1, rows):
        path.append((r, cols - 1))

    for step_idx, (r, c) in enumerate(path):
        # Empty floor, with border walls
        grid = [[0 for _ in range(cols)] for _ in range(rows)]
        for rr in range(rows):
            grid[rr][0] = 1
            grid[rr][cols - 1] = 1
        for cc in range(cols):
            grid[0][cc] = 1
            grid[rows - 1][cc] = 1

        grids.append(grid)
        player_positions.append((r, c))
        notes.append(f"Demo step {step_idx}")

    view_grids_with_pygame(
        grids,
        player_positions=player_positions,
        entrance=path[0],
        exit=path[-1],
        solution_paths=[set(path)] * len(grids),
        visited_cells=[set(path[:i + 1]) for i in range(len(path))],
        notes=notes,
        fps=15,
        cell_size=32,
        window_title="Maze Tycoon Demo Walk",
    )

if __name__ == "__main__":
    demo_walk()
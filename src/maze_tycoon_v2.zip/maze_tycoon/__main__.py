# maze_tycoon/__main__.py

from .game.ui_adapter import demo_walk_loop


def main() -> None:
    demo_walk_loop()

if __name__ == "__main__":
    main()
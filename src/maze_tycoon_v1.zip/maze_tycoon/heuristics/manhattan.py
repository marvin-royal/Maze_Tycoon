def h(a, b):
    ax, ay = a
    bx, by = b
    return abs(ax - bx) + abs(ay - by)
